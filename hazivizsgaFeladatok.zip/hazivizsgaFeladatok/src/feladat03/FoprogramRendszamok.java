package feladat03;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class FoprogramRendszamok {

	static Scanner sc = new Scanner(System.in);
	public static String tevekenyseg;
	
	public static <SzervizMunka> void main(String[] args) {
		
		Set<String> rendszamok = new HashSet<String>();
		
		
		String menupont = null;
		do {
			
			System.out.println("Válasszon menüpontot:");
			System.out.println("1. Adatfelvitel");
			System.out.println("2. Behajtás ellenőrzés");
			System.out.println("3. Kilépés");
			menupont = sc.nextLine();
			
			switch (menupont) {
			
			case "1":
				
				System.out.println(adatfelvitel(rendszamok)+" új rendszámot vitt fel a rendszerbe");				
				break;
				
			case "2":
				System.out.print("Adja meg a behajtani óhajtó autó rendszámát: ");
				String rendszam = sc.nextLine();
				if (behajthat(rendszamok,rendszam)) {
					
					System.out.println("Az autó behajthat a parkolóba!");
					
				}
				else {
					
					System.out.println("Az autó nem hajthat be a parkolóba!");

				}
				break;
				
			}
			
			
		}while(!menupont.equals("3"));
		
		// TODO Ide kerüljön  a statisztika kiíratása

		String szervizMunkak = null;
		// Statisztika kiíratása
		 // Statisztika kiíratása
       if (!szervizMunkak.isEmpty()) {
            SzervizMunka legHosszabbIdoTevekenyseg = legHosszabbIdo(szervizMunkak);
            if (legHosszabbIdoTevekenyseg != null) {
             //   System.out.println("A leghosszabb ideig tartó szervíztevékenység: " + legHosszabbIdoTevekenyseg.getTevekenyseg());
            //    System.out.println("Munkaórák száma: " + legHosszabbIdoTevekenyseg.getMunkaOrak());
            } else {
                System.out.println("Nincs rögzített szervíztevékenység.");
            }
        } else {
            System.out.println("Nincs rögzített szervíztevékenység.");
        }
    }

    private static String adatfelvitel(Set<String> rendszamok) {
		// XXX Auto-generated method stub
		return null;
	}

	private static <SzervizMunka> SzervizMunka legHosszabbIdo(String szervizMunkak) {
		// XXX Auto-generated method stub
		return null;
	}

	private static <SzervizMunka> int adatfelvitel(Set<SzervizMunka> SzervizMunkak, double oradiDij) {
        Scanner scanner = new Scanner(System.in);
        int ujRendszamokDarabszam = 0;

        while (true) {
            System.out.print("Adja meg a szervíztevékenységet (üres Enter kilépéshez): ");
            String tevekenyseg = scanner.nextLine();

            if (tevekenyseg.isEmpty()) {
              break;
            }
            System.out.print("Adja meg a munkaórák számát: ");
            int munkaOrak = scanner.nextInt();
            scanner.nextLine(); // Üres sor beolvasása

           SzervizMunka ujMunka = new SzervizMunkak(tevekenyseg, munkaOrak);
           SzervizMunkak.add(ujMunka);
            ujRendszamokDarabszam++;
        }

        return ujRendszamokDarabszam;}
    

    public static boolean behajthat(Set<String> rendszamok, String rendszam) {
        // Itt írd meg a behajthat metódus logikáját
        return false;
    }
}
