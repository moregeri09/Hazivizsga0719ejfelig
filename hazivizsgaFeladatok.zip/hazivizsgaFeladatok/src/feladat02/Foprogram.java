package feladat02;

public class Foprogram {

	public static void main(String[] args) {
		
		// ide kerüljön a tömb feltöltése majd a kiíratás:
		
		

	}

}
