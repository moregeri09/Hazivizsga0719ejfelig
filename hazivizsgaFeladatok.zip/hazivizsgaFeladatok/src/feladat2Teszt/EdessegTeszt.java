package feladat2Teszt;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat02.Edesseg;

public class EdessegTeszt {

	@Test
	void keszletErtekTeszt() {
		
		Edesseg edessegObj = new Edesseg("keksz", 390, 30);
		int elvartKeszletErtek = 390*30;
		
		assertTrue(elvartKeszletErtek, edessegObj.keszletErtek());
		
	}

	private void assertTrue(int elvartKeszletErtek, int keszletErtek) {
		
		
	}

}
