package feladat1Teszt;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat01.JelszoErosseg;

public class JelszoErossegTeszt {

	@Test
	void ellenorzesTest() {

		String jelszo = "Jojelszo45";
		assertEquals(JelszoErosseg.ellenorzes(jelszo));

	}

	private void assertEquals(boolean ellenorzes) {
		
		
	}
}
