package feladat3Teszt;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import feladat03.FoprogramRendszamok;

class FoprogramRendszamokTeszt {

	@Test
	void behajthatTeszt() {
		
		Set<String> rendszamok = new HashSet<String>();
		rendszamok.add("ABC-123");
		rendszamok.add("DEF-456");
		
		equals(FoprogramRendszamok.behajthat(rendszamok, "ABC-123"));
		
	}

}
