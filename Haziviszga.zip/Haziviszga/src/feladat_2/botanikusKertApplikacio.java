package feladat_2;

import java.time.LocalDate;

public class botanikusKertApplikacio {

	class Noveny {
		private int azonosito;
		private String megnevezes;
		private int bekerulesEve;

		public Noveny(int azonosito, String megnevezes, int bekerulesEve) {
			this.azonosito = azonosito;
			this.megnevezes = megnevezes;
			this.bekerulesEve = bekerulesEve;
		}

		public int getAzonosito() {
			return azonosito;
		}

		public String getMegnevezes() {
			return megnevezes;
		}

		public int getBekerulesEve() {
			return bekerulesEve;
		}

		public int getLathatosagHonapokban() {
			int aktualisEv = LocalDate.now().getYear();
			return (aktualisEv - bekerulesEve) * 12;
		}

		@Override
		public String toString() {
			return "Noveny{" + "azonosito=" + azonosito + ", megnevezes='" + megnevezes + '\'' + ", bekerulesEve="
					+ bekerulesEve + '}';
		}
	}

	class Virag extends Noveny {
		private String szin;

		public Virag(int azonosito, String megnevezes, int bekerulesEve, String szin) {
			super(azonosito, megnevezes, bekerulesEve);
			this.szin = szin;
		}

		@Override
		public String toString() {
			return "Virag{" + "azonosito=" + getAzonosito() + ", megnevezes='" + getMegnevezes() + '\''
					+ ", bekerulesEve=" + getBekerulesEve() + ", szin='" + szin + '\'' + '}';
		}
	}
	
	public class Main {
		public void main(String[] args) {
			Noveny[] novenyek = new Noveny[4];
			novenyek[0] = new Noveny(1, "Rózsa", 2018);
			novenyek[1] = new Virag(2, "Tulipán", 2020, "Piros");
			novenyek[2] = new Noveny(3, "Orgona", 2019);
			novenyek[3] = new Virag(4, "Nőszirom", 2021, "Fehér");

			kiirNovenyek(novenyek);
		}
	}

	public void kiirNovenyek(Noveny[] novenyek) {
		for (Noveny noveny : novenyek) {
			System.out.println(noveny.toString());
			System.out.println("Látogatható " + noveny.getLathatosagHonapokban() + " hónapja");
			if (noveny instanceof Virag) {
				System.out.println("Virág");
			} else {
				System.out.println("Általános növény");
			}
			System.out.println();
		}
	}
}
