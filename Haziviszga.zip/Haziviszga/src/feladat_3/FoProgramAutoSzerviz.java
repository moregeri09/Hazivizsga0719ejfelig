package feladat_3;
import java.util.*;
public class FoProgramAutoSzerviz {
		int oradij = 8000;

		public class TevekenysegRogzites {
		    public void main(String[] args) {
		        List<Tevekenyseg> tevekenysegek = new ArrayList<>();
		        Scanner scanner = new Scanner(System.in);

		        while (true) {
		            System.out.print("Kérem adja meg a szervíztevékenységet (vagy üres Enter a kilépéshez): ");
		            String szervizTevekenyseg = scanner.nextLine();

		            if (szervizTevekenyseg.isEmpty()) {
		                break; // Kilépés a ciklusból, ha üres Enter-t adott meg a felhasználó
		            }

		            System.out.print("Kérem adja meg az órák számát: ");
		            int orakSzama = scanner.nextInt();
		            scanner.nextLine(); // Töröljük a beolvasott sort a következő beolvasás előtt

		            Tevekenyseg tevekenyseg = new Tevekenyseg(szervizTevekenyseg, orakSzama);
		            tevekenysegek.add(tevekenyseg);
		        }

		        // Kiírjuk a rögzített tevékenységeket
		        System.out.println("Rögzített tevékenységek:");
		        for (Tevekenyseg tevekenyseg : tevekenysegek) {
		            System.out.println(tevekenyseg.getSzervizTevekenyseg() + " - " + tevekenyseg.getOrakSzama() + " óra");
		        }

		        // Megkeressük a leghosszabb ideig tartó tevékenységet
		        Tevekenyseg leghosszabbTevkenyseg = null;
		        for (Tevekenyseg tevekenyseg : tevekenysegek) {
		            if (leghosszabbTevkenyseg == null || tevekenyseg.getOrakSzama() > leghosszabbTevkenyseg.getOrakSzama()) {
		                leghosszabbTevkenyseg = tevekenyseg;
		            }
		        }

		        if (leghosszabbTevkenyseg != null) {
		            System.out.println("A leghosszabb ideig tartó tevékenység: " + leghosszabbTevkenyseg.getSzervizTevekenyseg());
		        }

		        // Map adatszerkezet létrehozása és feltöltése
		        Map<String, Integer> tevekenysegMunkadijMap = new HashMap<>();
		        for (Tevekenyseg tevekenyseg : tevekenysegek) {
		            int munkadij = tevekenyseg.arKepzes();
		            tevekenysegMunkadijMap.put(tevekenyseg.getSzervizTevekenyseg(), munkadij);
		        }

		        // Kiírjuk az adatokat a Map-ből
		        System.out.println("\nSzervíztevékenységek munkadíjai:");
		        for (Map.Entry<String, Integer> entry : tevekenysegMunkadijMap.entrySet()) {
		            System.out.println(entry.getKey() + " - " + entry.getValue() + " Ft");
		        }
		    }
		}

		class Tevekenyseg {
		    private String szervizTevekenyseg;
		    private int orakSzama;

		    public Tevekenyseg(String szervizTevekenyseg, int orakSzama) {
		        this.szervizTevekenyseg = szervizTevekenyseg;
		        this.orakSzama = orakSzama;
		    }

		    public String getSzervizTevekenyseg() {
		        return szervizTevekenyseg;
		    }

		    public int getOrakSzama() {
		        return orakSzama;
		    }

		    public int arKepzes() {
		        // Itt írd meg az arKepzes() metódust, ami visszaadja a munkadíjat az óraszám alapján
		        // Például: return orakSzama * 1000;
		        // Az itt alkalmazott képlet csak egy egyszerű példa, a valóságban a számításodnak attól függ, hogy milyen árképzést használsz.
		        return orakSzama * 1000;
		    }
		}

		
	}

