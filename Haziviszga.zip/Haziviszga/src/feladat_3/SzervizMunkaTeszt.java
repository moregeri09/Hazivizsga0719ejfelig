package feladat_3;

import feladat_3.SzervizMunka;

public class SzervizMunkaTeszt {

	class SzervizMunkaTest {

		@Test
		void arKepzesTeszt() {

			int oradij = 8000;
			SzervizMunka tesztObj = new SzervizMunka("olajcsere", 2);
			int elvartErtek = 16000;

			assertEquals(elvartErtek, tesztObj.arKepzes(oradij));

		}

		private void assertEquals(int elvartErtek, int arKepzes) {

		}

	}
}
