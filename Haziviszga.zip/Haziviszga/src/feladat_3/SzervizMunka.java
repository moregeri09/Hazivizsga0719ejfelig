package feladat_3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SzervizMunka {

	private String szervizTevekenyseg;
	private int munkaOra;

	public SzervizMunka(String szervizTevekenyseg, int munkaOra) {
		this.szervizTevekenyseg = szervizTevekenyseg;
		this.munkaOra = munkaOra;
	}

	public int arKepzes(int oradij) {

		return oradij * oradij * munkaOra;
	

		public class TevekenysegRogzites {
		    public static void main(String[] args) {
		        List<Tevekenyseg> tevekenysegek = new ArrayList<>();
		        Scanner scanner = new Scanner(System.in);

		        while (true) {
		            System.out.print("Kérem adja meg a szervíztevékenységet (vagy üres Enter a kilépéshez): ");
		            String szervizTevekenyseg = scanner.nextLine();

		            if (szervizTevekenyseg.isEmpty()) {
		                break; // Kilépés a ciklusból, ha üres Enter-t adott meg a felhasználó
		            }

		            System.out.print("Kérem adja meg az órák számát: ");
		            int orakSzama = scanner.nextInt();
		            scanner.nextLine(); // Töröljük a beolvasott sort a következő beolvasás előtt

		            Tevekenyseg tevekenyseg = new Tevekenyseg(szervizTevekenyseg, orakSzama);
		            tevekenysegek.add(tevekenyseg);
		        }

		        // Kiírjuk a rögzített tevékenységeket
		        System.out.println("Rögzített tevékenységek:");
		        for (Tevekenyseg tevekenyseg : tevekenysegek) {
		            System.out.println(tevekenyseg.getSzervizTevekenyseg() + " - " + tevekenyseg.getOrakSzama() + " óra");
		        }
		    }
		}

		class Tevekenyseg {
		    private String szervizTevekenyseg;
		    private int orakSzama;

		    public Tevekenyseg(String szervizTevekenyseg, int orakSzama) {
		        this.szervizTevekenyseg = szervizTevekenyseg;
		        this.orakSzama = orakSzama;
		    }

		    public String getSzervizTevekenyseg() {
		        return szervizTevekenyseg;
		    }

		    public int getOrakSzama() {
		        return orakSzama;
		    }
		}

	}
}
