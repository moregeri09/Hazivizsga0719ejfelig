package feladat_3;

public @interface Test {

	
}
