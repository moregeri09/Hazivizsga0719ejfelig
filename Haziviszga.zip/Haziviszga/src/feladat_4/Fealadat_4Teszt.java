package feladat_4;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import feladat04.FajlKezeles;

public class Fealadat_4Teszt {
	

	class FajlKezelesTest {

		@feladat_3.Test
		void ellenorizTeszt() {
			
			FajlKezeles fajlObj = new FajlKezeles();
			String[] tesztCsvSor = {"S0008","toll","100","4000","1"};
			
			assertTrue(fajlObj.ellenoriz(tesztCsvSor));}
		
			public boolean ellenoriz(String[] sor) {
			    if (sor.length < 5) {
			        return false;
			    }
			    if (sor[0].length() < 5) {
			        return false;
			    }
			    return true;
			}

		}

	public void assertTrue(Object ellenoriz) {
		// XXX Auto-generated method stub
		
	}
		
	}

