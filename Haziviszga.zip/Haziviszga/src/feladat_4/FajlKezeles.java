package feladat_4;

import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.List;

public class FajlKezeles {

	public Object ellenoriz(String[] tesztCsvSor) {
		

		class Rendeles {
		    private String szallitolevelAzonosito;
		    private String teteleMegnevezes;
		    private int mennyiseg;
		    private int osszertek;
		    private boolean surgosSzallitas;

		    // Konstruktor és getter/setter metódusok

		    @Override
		    public String toString() {
		        return "Szállítólevél azonosító: " + szallitolevelAzonosito +
		               ", Tétel megnevezés: " + teteleMegnevezes +
		               ", Mennyiség: " + mennyiseg +
		               ", Összérték: " + osszertek +
		               ", Sürgős szállítás: " + surgosSzallitas;
		    }
		}

		public class Main {
		    public void main(String[] args) {
		        List<Rendeles> rendelesek = new ArrayList<>();

		        // Rendelések hozzáadása a listához

		        // Rendelések kiírása
		        for (Rendeles rendeles : rendelesek) {
		            System.out.println(rendeles);
		        }
		    }
		}
		
		public class Rendeles {
		    // Mezők és korábbi konstruktor/getter/setter metódusok

		    private String szallitolevelAzonosito;
			private String teteleMegnevezes;
			private int mennyiseg;
			private int osszertek;
			private boolean surgosSzallitas;

			public Rendeles(String szallitolevelAzonosito, String teteleMegnevezes, int mennyiseg, int osszertek, boolean surgosSzallitas) {
		        
		       
		       
		      
		        
		    }

			public String getSzallitolevelAzonosito() {
				this.szallitolevelAzonosito = szallitolevelAzonosito;
				return null;
			}

			public String getTeteleMegnevezes() {
				 this.teteleMegnevezes = teteleMegnevezes;
				return null;
			}

			public String getMennyiseg() {
				 this.mennyiseg = mennyiseg;
				return null;
			}

			public String getOsszertek() {
				  this.osszertek = osszertek;
				return null;
			}

			public boolean isSurgosSzallitas() {
				this.surgosSzallitas = surgosSzallitas;
				return false;
			}
		}

		public class Main {
		    public void main(String[] args) {
		        List<Rendeles> rendelesek = new ArrayList<>();

		        // Rendelések hozzáadása a listához
		        rendelesek.add(new Rendeles("S0001", "toll", 100, 4000, true));
		        rendelesek.add(new Rendeles("S0002", "radír", 50, 1000, false));

		        // Rendelések kiírása
		        for (Rendeles rendeles : rendelesek) {
		            System.out.println(rendeles);
		        }
		    }
		}


		public class FajlKezeles {
		    // ...

		    public void kiir(List<Rendeles> rendelesek) {
		        try (BufferedWriter writer = new BufferedWriter(new FileWriter("UjSzallitoiRendelesek.csv"))) {
		            // Fejléc írása
		            writer.write("Szállítólevél azonosító;Tétel megnevezés;Mennyiség;Összérték;Sürgős szállítás\n");

		            // Rendelések kiírása
		            for (Rendeles rendeles : rendelesek) {
		                writer.write(rendeles.getSzallitolevelAzonosito() + ";" +
		                             rendeles.getTeteleMegnevezes() + ";" +
		                             rendeles.getMennyiseg() + ";" +
		                             rendeles.getOsszertek() + ";" +
		                             (rendeles.isSurgosSzallitas() ? "1" : "0") + "\n");
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		    }
		}

		public class Main {
		    public void main(String[] args) {
		        List<Rendeles> rendelesek = new ArrayList<>();

		        // Rendelések hozzáadása a listához

		        // Rendelések kiírása
		        for (Rendeles rendeles : rendelesek) {
		            System.out.println(rendeles);
		        }

		        FajlKezeles fajlKezeles = new FajlKezeles();
		        fajlKezeles.kiir(rendelesek);
		    }
		}

		return null;
	}

}
