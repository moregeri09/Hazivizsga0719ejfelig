package feladat_1;

public class TitkositoEllenorzes {

	class titkositoApplikacioTest {

		
		void titkositTeszt() {
			
			String titkositando = "Tesztszöveg ellenőrzése";
			String elvartEredmeny = "7T73z53zöv7g07ll7nőrzé3";
			assertEquals(elvartEredmeny, TitkositoApplikacio.titkosit(titkositando));
			
		}

		private void assertEquals(String elvartEredmeny, String titkosit) {
			
			
		}

	}
	
	
}
