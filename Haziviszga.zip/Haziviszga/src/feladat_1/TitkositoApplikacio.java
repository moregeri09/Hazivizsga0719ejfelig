package feladat_1;

	import java.util.Scanner;

	import java.util.Scanner;

	public class TitkositoApplikacio {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Adjon meg egy titkosítandó szöveget:");
	        String szoveg = scanner.nextLine();

	        String titkosSzoveg = titkosit(szoveg);
	        System.out.println("A titkosított változat: " + titkosSzoveg);

	        String visszafejtettSzoveg = dekodol(titkosSzoveg);
	        System.out.println("A visszafejtett változat: " + visszafejtettSzoveg);
	    }

	    public static String titkosit(String titkositando) {
	        String mitKellCserelni = "kstea";
	        String mireKellCserelni = "135790";

	        String eredmeny = titkositando.replace(' ', '0');

	        for (int i = 0; i < mitKellCserelni.length(); i++) {
	            char karakter = mitKellCserelni.charAt(i);
	            char csere = mireKellCserelni.charAt(i);
	            eredmeny = eredmeny.replace(karakter, csere);
	        }

	        if (eredmeny.length() > 1) {
	            eredmeny = eredmeny.charAt(eredmeny.length() - 1) + eredmeny.substring(0, eredmeny.length() - 1);
	        }

	        return eredmeny;
	    }

	    public static String dekodol(String titkositott) {
	        String mitKellCserelni = "135790";
	        String mireKellCserelni = "kstea";

	        if (titkositott.length() > 1) {
	            titkositott = titkositott.charAt(titkositott.length() - 1) + titkositott.substring(0, titkositott.length() - 1);
	        }

	        for (int i = 0; i < mitKellCserelni.length(); i++) {
	            char karakter = mitKellCserelni.charAt(i);
	            char csere = mireKellCserelni.charAt(i);
	            titkositott = titkositott.replace(karakter, csere);
	        }

	        titkositott = titkositott.replace('0', ' ');

	        return titkositott;
	    }
	}

	

